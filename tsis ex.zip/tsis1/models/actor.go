package models

type Actor struct {
	Name string `json:"name"`
	Age  int    `json:"age"`
	Role string `json:"role"`
}
